#ifndef LinearAlgebraReductionTool_h__
#define LinearAlgebraReductionTool_h__


#endif // LinearAlgebraReductionTool_h__
