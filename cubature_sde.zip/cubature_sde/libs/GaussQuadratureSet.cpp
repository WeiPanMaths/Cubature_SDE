/* Copyright -  All Rights Reserved - Terry Lyons 2008 */
#include ".\gaussquadratureset.h"

//#include "stdafx.h"
#include <iostream>

const CHighPrecisionGaussianQuadratures<6> CGQ6;

CGaussQuadratureSet::CGaussQuadratureSet(void) {}

CGaussQuadratureSet::~CGaussQuadratureSet(void) {}
