/* Copyright -  All Rights Reserved - Terry Lyons 2008 */
#pragma once


#include <iostream>
#include <tchar.h>

