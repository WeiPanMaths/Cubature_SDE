#pragma once

struct OptionData
{
	double barrier;
	double strike;
	double time;
};