#ifndef ToPowersData_h__
#define ToPowersData_h__
#include "BufferConstructor.h"

struct CConditioning
{
	double dMean;
	double dStdDev;
};

#endif // ToPowersData_h__
