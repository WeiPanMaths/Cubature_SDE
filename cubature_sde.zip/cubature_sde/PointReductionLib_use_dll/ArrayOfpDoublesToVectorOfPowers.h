#ifndef ArrayOfpDoublesToVectorOfPowers_h__
#define ArrayOfpDoublesToVectorOfPowers_h__

#ifdef __cplusplus
extern "C"
{
#endif

	void ArrayOfpDoublesToVectorOfPowers(void* pIn, double* pOut, void* vpCBufferHelper);
	void ArrayOfpDoublesToVectorOfPowers1(void* pIn, double* pOut, void* vpCConditionedBufferHelper);

#ifdef __cplusplus
}
#endif

#endif // ArrayOfpDoublesToVectorOfPowers_h__
