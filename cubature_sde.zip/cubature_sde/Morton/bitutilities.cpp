////////////////////////////////////////////////////////
// ALL rights reserved to the author of this software
// Terry Lyons 
// 2011 - 2012
///////////////////////////////////////////////////////
// bitutilities.cpp : Defines main code for the console application.
//

#include "stdafx.h"
#include "bitutilities.h"